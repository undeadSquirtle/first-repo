select * from datDragons WHERE age >= 1000 and heads=1 order by age
